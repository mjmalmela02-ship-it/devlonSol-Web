import { describe, it, expect } from "vitest";
import { invoiceTotal } from "@/lib/invoice";

describe("invoice total", () => {
  it("never goes below the R1000 basic package minimum", () => {
    expect(invoiceTotal([{ description: "x", qty: 1, price: 200 }])).toBe(1000);
  });
  it("adds extras on top of the basic package", () => {
    expect(invoiceTotal([{ description: "a", qty: 1, price: 1000 }, { description: "b", qty: 2, price: 250 }])).toBe(1500);
  });
});
