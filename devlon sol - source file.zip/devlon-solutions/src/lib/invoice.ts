export const BASIC_PACKAGE_PRICE = 1000; // ZAR minimum: basic website + 1 year domain & maintenance

export type LineItem = { description: string; qty: number; price: number };

export function invoiceTotal(items: LineItem[]) {
  const sum = items.reduce((t, i) => t + Math.max(0, i.qty) * Math.max(0, i.price), 0);
  return Math.max(BASIC_PACKAGE_PRICE, sum);
}

// Deterministic (same on server and browser): "R 1 000.00"
export const formatZAR = (n: number) => {
  const [int = "0", dec = "00"] = (Math.round(n * 100) / 100).toFixed(2).split(".");
  return "R " + int.replace(/\B(?=(\d{3})+(?!\d))/g, " ") + "." + dec;
};
