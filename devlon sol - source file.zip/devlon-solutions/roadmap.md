# Roadmap
- [x] Printing page: quote fields (type, size, quantity, finishing) in WhatsApp message
- [x] AI chat assistant: separate conversations, saved in Cloud, real enquiries saved as leads + WhatsApp handoff
